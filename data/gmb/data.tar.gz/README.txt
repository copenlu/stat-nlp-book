Source:
https://www.kaggle.com/shoumikgoswami/annotated-gmb-corpus/

License:
Database Contents License (DbCL) v1.0
https://opendatacommons.org/licenses/dbcl/1.0/

